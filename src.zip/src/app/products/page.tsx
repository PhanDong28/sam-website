import { prisma } from "@/lib/prisma";
import Link from "next/link";
import Image from "next/image";
import Navbar from "@/components/public/Navbar";
import Footer from "@/components/public/Footer";
import type { Metadata } from "next";

const GOLD = "#c9a84c";

export const metadata: Metadata = {
  title: "Toàn Bộ Sản Phẩm | Hữu Sâm",
  description: "Sâm Ngọc Linh, sâm Lai Châu, rượu sâm và các sản phẩm sâm chính gốc Việt Nam, nguồn gốc rõ ràng, chất lượng đảm bảo.",
};

export default async function ProductsPage({ searchParams }: { searchParams: Promise<{ category?: string }> }) {
  const { category } = await searchParams;
  const [products, categories] = await Promise.all([
    prisma.product.findMany({
      where: {
        isPublished: true,
        ...(category ? { category: { slug: category } } : {}),
      },
      orderBy: [{ isFeatured: "desc" }, { createdAt: "desc" }],
      include: { category: true },
    }),
    prisma.category.findMany({ orderBy: { name: "asc" } }),
  ]);

  return (
    <>
      <Navbar />
      <div style={{ background: "#faf7f0", minHeight: "100vh" }}>
        {/* Header */}
        <div style={{
          background: "linear-gradient(160deg, #140d00, #1e1200)",
          padding: "72px 32px 56px",
          borderBottom: "1px solid rgba(201,168,76,0.15)",
        }}>
          <div style={{ maxWidth: 1180, margin: "0 auto" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 18 }}>
              <div style={{ width: 32, height: 1, background: GOLD }} />
              <span style={{ fontSize: 10, letterSpacing: "0.3em", color: GOLD }}>BỘ SƯU TẬP</span>
            </div>
            <h1 style={{ fontSize: 38, fontWeight: 300, color: "#f0d070", fontFamily: "var(--font-serif), Georgia, serif", margin: 0 }}>
              Toàn Bộ Sản Phẩm
            </h1>
          </div>
        </div>

        {/* Category chips */}
        {categories.length > 0 && (
          <div style={{ maxWidth: 1180, margin: "0 auto", padding: "32px 32px 0", display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
            <Link href="/products" style={{
              fontSize: 12, padding: "9px 20px", borderRadius: 20, textDecoration: "none",
              letterSpacing: "0.03em", fontWeight: 500, transition: "all 0.2s ease",
              ...(category ? {
                border: "1px solid #e8d9b0", color: "#7a6040", background: "#fff",
              } : {
                background: `linear-gradient(135deg, ${GOLD}, #9e7820)`, color: "#fff",
                boxShadow: "0 6px 16px rgba(158,120,32,0.3)",
              }),
            }}>
              Tất cả
            </Link>
            {categories.map(c => {
              const active = category === c.slug;
              return (
                <Link key={c.id} href={`/products?category=${c.slug}`} className="lift-hover" style={{
                  fontSize: 12, padding: "9px 20px", borderRadius: 20, textDecoration: "none",
                  letterSpacing: "0.03em", transition: "all 0.2s ease",
                  ...(active ? {
                    background: `linear-gradient(135deg, ${GOLD}, #9e7820)`, color: "#fff",
                    boxShadow: "0 6px 16px rgba(158,120,32,0.3)",
                  } : {
                    border: "1px solid #e8d9b0", color: "#7a6040", background: "#fff",
                  }),
                }}>
                  {c.name}
                </Link>
              );
            })}
          </div>
        )}

        {/* Result count */}
        <div style={{ maxWidth: 1180, margin: "0 auto", padding: "24px 32px 0" }}>
          <p style={{ fontSize: 12, color: "#a8895a", letterSpacing: "0.02em", margin: 0 }}>
            {products.length} sản phẩm{category ? " trong danh mục này" : ""}
          </p>
        </div>

        {/* Products grid */}
        <div style={{ maxWidth: 1180, margin: "0 auto", padding: "20px 32px 80px" }}>
          {products.length === 0 ? (
            <p style={{ textAlign: "center", color: "#b09060", padding: "80px 0", fontSize: 14 }}>
              Chưa có sản phẩm nào
            </p>
          ) : (
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 28 }}>
              {products.map((p, i) => (
                <Link key={p.id} href={`/products/${p.slug}`} style={{ textDecoration: "none" }}>
                  <div className="product-card fade-in-up" style={{ animationDelay: `${i * 0.05}s` }}>
                    <div className="img-zoom" style={{
                      aspectRatio: "4/3", position: "relative", overflow: "hidden",
                      background: "linear-gradient(150deg, #f7efdd 0%, #ecdfbb 55%, #e3d3a4 100%)",
                    }}>
                      <div style={{
                        position: "absolute", inset: 0,
                        backgroundImage: "radial-gradient(circle at 30% 30%, rgba(255,255,255,0.5), transparent 60%)",
                      }} />
                      {p.images?.[0] ? (
                        <Image src={p.images[0]} alt={p.name} fill sizes="(max-width: 768px) 100vw, 400px" style={{ objectFit: "cover", position: "relative" }} />
                      ) : (
                        <div style={{ width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center", position: "relative" }}>
                          <span style={{ fontSize: 48, filter: "drop-shadow(0 6px 10px rgba(120,90,30,0.25))" }}>🌿</span>
                        </div>
                      )}
                      {p.isFeatured && (
                        <div style={{
                          position: "absolute", top: 14, left: 14,
                          background: `linear-gradient(135deg, ${GOLD}, #9e7820)`, color: "#fff", fontSize: 9,
                          letterSpacing: "0.15em", padding: "5px 12px", borderRadius: 20,
                          boxShadow: "0 4px 10px rgba(158,120,32,0.35)",
                        }}>NỔI BẬT</div>
                      )}
                    </div>
                    <div style={{ padding: "22px 22px 20px" }}>
                      {p.category && (
                        <span style={{
                          fontSize: 9, letterSpacing: "0.15em", color: "#9e7820", fontWeight: 600,
                          background: "#f7efd9", padding: "3px 9px", borderRadius: 4,
                        }}>{p.category.name.toUpperCase()}</span>
                      )}
                      <h3 style={{ fontSize: 17, color: "#1a1000", margin: "12px 0 16px", fontWeight: 500, fontFamily: "var(--font-serif), Georgia, serif", lineHeight: 1.35 }}>
                        {p.name}
                      </h3>
                      <div style={{
                        display: "flex", alignItems: "center", justifyContent: "space-between",
                        paddingTop: 14, borderTop: "1px solid #f0e6cc",
                      }}>
                        <span style={{ fontSize: 11, color: "#9e7820", letterSpacing: "0.04em", fontWeight: 500 }}>Liên hệ báo giá</span>
                        <span className="card-arrow" style={{
                          width: 28, height: 28, borderRadius: "50%", display: "flex",
                          alignItems: "center", justifyContent: "center", fontSize: 14, color: GOLD,
                          border: `1px solid ${GOLD}55`,
                        }}>→</span>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>
      <Footer />
    </>
  );
}